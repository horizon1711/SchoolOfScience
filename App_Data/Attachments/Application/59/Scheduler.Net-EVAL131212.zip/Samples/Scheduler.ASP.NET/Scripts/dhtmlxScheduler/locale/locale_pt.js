/*
Copyright Dinamenta, UAB. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
Scheduler.plugin(function(a){a.locale={date:{month_full:"Janeiro,Fevereiro,Mar\u00e7o,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro".split(","),month_short:"Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez".split(","),day_full:"Domingo,Segunda,Ter\u00e7a,Quarta,Quinta,Sexta,S\u00e1bado".split(","),day_short:"Dom,Seg,Ter,Qua,Qui,Sex,Sab".split(",")},labels:{dhx_cal_today_button:"Hoje",day_tab:"Dia",week_tab:"Semana",month_tab:"M\u00eas",new_event:"Novo evento",icon_save:"Salvar",
icon_cancel:"Cancelar",icon_details:"Detalhes",icon_edit:"Editar",icon_delete:"Deletar",confirm_closing:"",confirm_deleting:"Tem certeza que deseja excluir?",section_description:"Descri\u00e7\u00e3o",section_time:"Per\u00edodo de tempo",full_day:"Dia inteiro",confirm_recurring:"Deseja editar todos esses eventos repetidos?",section_recurring:"Repetir evento",button_recurring:"Desabilitar",button_recurring_open:"Habilitar",button_edit_series:"Editar a s\u00e9rie",button_edit_occurrence:"Editar uma c\u00f3pia",
agenda_tab:"Dia",date:"Data",description:"Descri\u00e7\u00e3o",year_tab:"Ano",week_agenda_tab:"Dia",grid_tab:"Grade"}}});
