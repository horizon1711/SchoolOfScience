/*
Copyright Dinamenta, UAB. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
Scheduler.plugin(function(a){a.locale={date:{month_full:"Ocak,\u00deubat,Mart,Nisan,May\u00fds,Haziran,Temmuz,A\u00f0ustos,Eyl\u00fcl,Ekim,Kas\u00fdm,Aral\u00fdk".split(","),month_short:"Oca,\u00deub,Mar,Nis,May,Haz,Tem,A\u00f0u,Eyl,Eki,Kas,Ara".split(","),day_full:"Pazar Pazartes, Sal\u00fd \u00c7ar\u00feamba Per\u00feembe Cuma Cumartesi".split(" "),day_short:"Paz,Pts,Sal,\u00c7ar,Per,Cum,Cts".split(",")},labels:{dhx_cal_today_button:"Bug\u00fcn",day_tab:"G\u00fcn",week_tab:"Hafta",month_tab:"Ay",
new_event:"Uygun",icon_save:"Kaydet",icon_cancel:"\u00ddptal",icon_details:"Detaylar",icon_edit:"D\u00fczenle",icon_delete:"Sil",confirm_closing:"",confirm_deleting:"Etkinlik silinecek, devam?",section_description:"A\u00e7\u00fdklama",section_time:"Zaman aral\u00fd\u00f0\u00fd",full_day:"Tam g\u00fcn",confirm_recurring:"T\u00fcm tekrar eden etkinlikler silinecek, devam?",section_recurring:"Etkinli\u00f0i tekrarla",button_recurring:"Pasif",button_recurring_open:"Aktif",button_edit_series:"Dizi d\u00fczenleme",
button_edit_occurrence:"Bir kopyas\u0131n\u0131 d\u00fczenleyin",agenda_tab:"Ajanda",date:"Tarih",description:"A\u00e7\u00fdklama",year_tab:"Y\u00fdl",week_agenda_tab:"Ajanda",grid_tab:"Izgara"}}});
