/*
Copyright Dinamenta, UAB. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
Scheduler.plugin(function(a){a.locale={date:{month_full:"Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre".split(","),month_short:"Ene,Feb,Mar,Abr,May,Jun,Jul,Ago,Sep,Oct,Nov,Dic".split(","),day_full:"Domingo,Lunes,Martes,Mi\u00e9rcoles,Jueves,Viernes,S\u00e1bado".split(","),day_short:"Dom,Lun,Mar,Mi\u00e9,Jue,Vie,S\u00e1b".split(",")},labels:{dhx_cal_today_button:"Hoy",day_tab:"D\u00eda",week_tab:"Semana",month_tab:"Mes",new_event:"Nuevo evento",icon_save:"Guardar",
icon_cancel:"Cancelar",icon_details:"Detalles",icon_edit:"Editar",icon_delete:"Eliminar",confirm_closing:"",confirm_deleting:"El evento se borrar\u00e1 definitivamente, \u00bfcontinuar?",section_description:"Descripci\u00f3n",section_time:"Per\u00edodo",full_day:"Todo el d\u00eda",confirm_recurring:"\u00bfDesea modificar el conjunto de eventos repetidos?",section_recurring:"Repita el evento",button_recurring:"Impedido",button_recurring_open:"Permitido",button_edit_series:"Editar la serie",button_edit_occurrence:"Editar una copia",
agenda_tab:"D\u00eda",date:"Fecha",description:"Descripci\u00f3n",year_tab:"A\u00f1o",week_agenda_tab:"D\u00eda",grid_tab:"Reja"}}});
