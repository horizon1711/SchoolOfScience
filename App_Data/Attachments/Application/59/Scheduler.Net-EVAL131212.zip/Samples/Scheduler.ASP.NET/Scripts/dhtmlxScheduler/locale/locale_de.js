/*
Copyright Dinamenta, UAB. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
Scheduler.plugin(function(a){a.locale={date:{month_full:" Januar, Februar, M\u00e4rz , April, Mai, Juni, Juli, August, September , Oktober, November , Dezember".split(","),month_short:"Jan,Feb,M\u00e4r,Apr,Mai,Jun,Jul,Aug,Sep,Okt,Nov,Dec".split(","),day_full:"Sonntag,Montag,Dienstag, Mittwoch, Donnerstag,Freitag,Samstag".split(","),day_short:"So,Mo,Di,Mi,Do,Fr,Sa".split(",")},labels:{dhx_cal_today_button:"Heute",day_tab:"Tag",week_tab:"Woche",month_tab:"Monat",new_event:"neuer Eintrag",icon_save:"Speichern",
icon_cancel:"Abbrechen",icon_details:"Details",icon_edit:"\u00c4ndern",icon_delete:"L\u00f6schen",confirm_closing:"",confirm_deleting:"Der Eintrag wird gel\u00f6scht",section_description:"Beschreibung",section_time:"Zeitspanne",full_day:"Ganzer Tag",confirm_recurring:"Wollen Sie alle Eintr\u00e4ge bearbeiten oder nur diesen einzelnen Eintrag?",section_recurring:"Wiederholung",button_recurring:"Aus",button_recurring_open:"An",button_edit_series:"Bearbeiten Sie die Serie",button_edit_occurrence:"Bearbeiten Sie eine Kopie",
agenda_tab:"Agenda",date:"Datum",description:"Beschreibung",year_tab:"Jahre",week_agenda_tab:"Agenda",grid_tab:"Grid"}}});
