/*
Copyright Dinamenta, UAB. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
Scheduler.plugin(function(a){a.locale={date:{month_full:"Januar,Februar,Marec,April,Maj,Junij,Julij,Avgust,September,Oktober,November,December".split(","),month_short:"Jan,Feb,Mar,Apr,Maj,Jun,Jul,Aug,Sep,Okt,Nov,Dec".split(","),day_full:"Nedelja,Ponedeljek,Torek,Sreda,\u010cetrtek,Petek,Sobota".split(","),day_short:"Ned,Pon,Tor,Sre,\u010cet,Pet,Sob".split(",")},labels:{dhx_cal_today_button:"Danes",day_tab:"Dan",week_tab:"Teden",month_tab:"Mesec",new_event:"Nov dogodek",icon_save:"Shrani",icon_cancel:"Prekli\u010di",
icon_details:"Podrobnosti",icon_edit:"Uredi",icon_delete:"Izbri\u0161i",confirm_closing:"",confirm_deleting:"Dogodek bo izbrisan. \u017delite nadaljevati?",section_description:"Opis",section_time:"\u010casovni okvir",full_day:"Ves dan",confirm_recurring:"\u017delite urediti celoten set ponavljajo\u010dih dogodkov?",section_recurring:"Ponovi dogodek",button_recurring:"Onemogo\u010deno",button_recurring_open:"Omogo\u010deno",button_edit_series:"Edit series",button_edit_occurrence:"Edit occurrence",
agenda_tab:"Zadeva",date:"Datum",description:"Opis",year_tab:"Leto",week_agenda_tab:"Zadeva",grid_tab:"Miza"}}});
