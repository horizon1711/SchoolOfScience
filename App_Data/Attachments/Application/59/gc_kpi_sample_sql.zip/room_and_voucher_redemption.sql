-- Room and voucher redemption
SELECT * FROM
(
select To_Char(date_awarded, 'yyyy-mm') date_awarded,
substr(a.award_type,1,instr(a.award_type,'-')-1) property,
CASE WHEN a.award_type LIKE '%-GCRR' THEN 'GCRR'
WHEN a.award_type LIKE '%-GCRS%' THEN 'GCRS'
WHEN a.award_type LIKE '%-ECT-R%' THEN 'ECT-R'
WHEN a.award_type LIKE '%-ECT1-R%' THEN 'ECT-R'
WHEN a.award_type LIKE '%-ECT2-R%' THEN 'ECT-R'
WHEN a.award_type LIKE '%-ECT-C%' THEN 'ECT-C'
WHEN a.award_type LIKE '%-ECT-S%' THEN 'ECT-S'
WHEN a.award_type LIKE '%-ECT1-S%' THEN 'ECT-S'
WHEN a.award_type LIKE '%-UPGC' THEN 'UPGC'
ELSE 'UNKNOWN' end award,
a.membership_level,
sum(CASE WHEN a.award_cancel_date is null or a.award_cancel_date >= to_date('20110701','yyyymmdd')
then nvl(number_of_nights,1) else 0 end) num_of_nights, -- for data check only
sum(CASE WHEN (Nvl(a.actual_cancel_points, 0) > 0 AND a.award_cancel_date < to_date('20110701','yyyymmdd'))
then nvl(number_of_nights,1) else 0 end) penalty_num_of_nights, -- for data check only
sum(CASE WHEN a.award_cancel_date is null or a.award_cancel_date >= to_date('20110701','yyyymmdd')
then 1 else 0 end) num_of_trx, -- for data check only
sum(CASE WHEN (Nvl(a.actual_cancel_points, 0) > 0 AND a.award_cancel_date < to_date('20110701','yyyymmdd'))
then 1 else 0 end) penalty_num_of_trx, -- for data check only
sum(CASE WHEN a.award_cancel_date is null or a.award_cancel_date >= to_date('20110701','yyyymmdd')
then
CASE WHEN a.award_type LIKE '%-ECT-%' THEN nvl(number_of_nights,1) * SubStr(a.award_type,InStr(a.award_type,'ECT')+5)
else nvl(number_of_nights,1) end
else 0 end) num_of_vouchers_or_nights,
sum(CASE WHEN (Nvl(a.actual_cancel_points, 0) > 0 AND a.award_cancel_date < to_date('20110701','yyyymmdd'))
then
CASE WHEN a.award_type LIKE '%-ECT-%' THEN nvl(number_of_nights,1) * SubStr(a.award_type,InStr(a.award_type,'ECT')+5)
else nvl(number_of_nights,1) end
else 0 end) penalty_num_of_vouch_or_night,
sum(case when (a.award_cancel_date is null or a.award_cancel_date >= to_date('20110701','yyyymmdd'))
then a.points_required
else 0 end) gc_points_used,
sum(case WHEN (Nvl(a.actual_cancel_points, 0) > 0 AND a.award_cancel_date < to_date('20110701','yyyymmdd'))
THEN a.actual_cancel_points
else 0 end) penalty_gc_points,
a.award_cancel_date > to_date('20110304','yyyymmdd'))
Nvl(nvl(b.issue_source, d.channel), app_user) channel
from opera.membership_issued_awards a,
opera.OPERA_ECERTS b,
opera.APPLICATION$_USER c,
opera.reservation_name d
where a.insert_user = c.app_user_id (+)
and a.local_RESV_NAME_ID = d.RESV_NAME_ID (+)
and date_awarded >= to_date('20110101','yyyymmdd')
and date_awarded < to_date('20110701','yyyymmdd')
and a.ISSUED_AWARD_ID = b.membership_award_id (+)
group by To_Char(date_awarded, 'yyyy-mm'),
substr(a.award_type,1,instr(a.award_type,'-')-1),
CASE WHEN a.award_type LIKE '%-GCRR' THEN 'GCRR'
WHEN a.award_type LIKE '%-GCRC' THEN 'GCRC'
WHEN a.award_type LIKE '%-GCRS%' THEN 'GCRS'
WHEN a.award_type LIKE '%-ECT-R%' THEN 'ECT-R'
WHEN a.award_type LIKE '%-ECT1-R%' THEN 'ECT-R'
WHEN a.award_type LIKE '%-ECT2-R%' THEN 'ECT-R'
WHEN a.award_type LIKE '%-ECT-C%' THEN 'ECT-C'
WHEN a.award_type LIKE '%-ECT-S%' THEN 'ECT-S'
WHEN a.award_type LIKE '%-ECT1-S%' THEN 'ECT-S'
WHEN a.award_type LIKE '%-UPGC' THEN 'UPGC'
ELSE 'UNKNOWN' end,
a.membership_level, Nvl(nvl(b.issue_source, d.channel), app_user)
)
WHERE Nvl(num_of_nights, 0) > 0
or Nvl(num_of_trx, 0) > 0
or Nvl(gc_points_used, 0) > 0
or Nvl(num_of_vouchers_or_nights, 0) > 0
or Nvl(penalty_num_of_nights, 0) > 0
or Nvl(penalty_num_of_trx, 0) > 0
or Nvl(penalty_num_of_vouch_or_night, 0) > 0
or Nvl(penalty_gc_points, 0) > 0
