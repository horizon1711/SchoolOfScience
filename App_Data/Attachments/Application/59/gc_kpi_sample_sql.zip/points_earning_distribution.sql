-- points earning distribution
SELECT To_Char(end_date, 'yyyy-mm') end_date, a.resort, CASE WHEN a.adjustment_yn = 'Y' THEN 'ADJUSTMENT (Calculated)'
WHEN b.record_type = 'CHECKED OUT' THEN 'STAY (Calculated)'
ELSE a.pos_code END TYPE, b.record_type, a.membership_level, Sum(total_base_points) total_base_points, Sum(total_points) total_points,
count(*) num_of_trx
FROM opera.tmp_ricky_gc_pts a, opera.stay_records b
WHERE a.end_date >= To_Date('20101025', 'yyyymmdd')
AND a.end_date < To_Date('20110701', 'yyyymmdd')
AND a.stay_record_id = b.stay_record_id (+)
GROUP BY To_Char(end_date, 'yyyy-mm'), a.resort,
CASE WHEN a.adjustment_yn = 'Y' THEN 'ADJUSTMENT (Calculated)'
WHEN b.record_type = 'CHECKED OUT' THEN 'STAY (Calculated)'
ELSE a.pos_code END,
b.record_type, a.membership_level
