-- diamond member met renew criteria
SELECT a.membership_level,
Sum(
CASE WHEN a.membership_level = 'DIAMOND' AND (Nvl(b.udfn09,0) >= 50 or Nvl(b.udfn10,0) >=25) THEN 1
when a.membership_level = 'JADE' AND (Nvl(b.udfn09,0) >= 20 or Nvl(b.udfn10,0) >=10) THEN 1
ELSE 0 END
) num_met_criteria
FROM opera.memberships a,
opera.NAME b
WHERE a.membership_type = 'GC'
and nvl(a.inactive_date, sysdate+1) > SYSDATE
AND a.membership_level IS NOT NULL
AND a.name_id = b.name_id
--AND a.name_id = c.name_id (+)
--AND a.membership_level IN ('GOLD')
AND a.membership_level IN ('JADE')
--AND a.membership_level IN ('DIAMOND')
GROUP BY a.membership_level
